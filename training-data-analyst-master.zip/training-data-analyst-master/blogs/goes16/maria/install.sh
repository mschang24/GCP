#!/bin/bash
sudo apt-get install python-pip
sudo pip install pyresample
sudo pip install netcdf4
sudo pip install matplotlib
sudo apt-get install python-tk
sudo pip install pillow
sudo pip install google-cloud-dataflow
sudo pip install google-cloud-storage
