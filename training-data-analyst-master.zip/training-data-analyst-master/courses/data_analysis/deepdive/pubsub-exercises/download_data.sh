#!/bin/bash
gsutil -m cp gs://cloud-training-demos/datasme/pubsub/actions.csv data/actions.csv
